package fr.eni.ecole.encheres.bllCategorie;

public class ParameterException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ParameterException(String message) {
		super(message);
	}


}
